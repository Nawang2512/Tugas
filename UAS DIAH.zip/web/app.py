import streamlit as st
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
import pandas as pd

# Fungsi untuk stemming Bahasa Indonesia
factory = StemmerFactory()
stemmer = factory.create_stemmer()

# Memuat dataset KBBI
def load_kbbi_dataset():
    data = pd.read_csv('kbbi_dataset.csv')
    return data

# Fungsi untuk mencari arti kata dalam dataset
def get_kbbi_definition(word, kbbi_data):
    result = kbbi_data[kbbi_data['kata'] == word]
    if not result.empty:
        return result.iloc[0]['arti']
    else:
        return "Definisi tidak ditemukan dalam dataset."

# Memuat data KBBI
kbbi_data = load_kbbi_dataset()

# Menambahkan gaya CSS untuk background dan elemen lainnya
st.markdown("""
    <style>
        body {
            background-color: #FAFAFA;
            font-family: 'Arial', sans-serif;
        }
        .main-container {
            background: linear-gradient(135deg, #4CAF50, #81C784);
            color: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            margin-bottom: 20px;
        }
        .main-title {
            font-size: 40px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .subtitle {
            font-size: 20px;
            margin-bottom: 20px;
        }
        .input-container {
            background-color: #FFF;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .result-container {
            padding: 20px;
            border-radius: 10px;
            font-size: 18px;
            margin-top: 20px;
            text-align: center;
        }
        .result-success {
            background-color: #C8E6C9;
            color: #2E7D32;
            border: 2px solid #81C784;
        }
        .result-error {
            background-color: #FFCDD2;
            color: #C62828;
            border: 2px solid #EF5350;
        }
    </style>
""", unsafe_allow_html=True)

# Bagian judul aplikasi
st.markdown("<div class='main-container'><div class='main-title'>Pencarian Makna Kata KBBI</div><div class='subtitle'>Cari makna kata dalam Bahasa Indonesia</div></div>", unsafe_allow_html=True)

# Input kata atau kalimat
st.markdown("<div class='input-container'>Masukkan kata atau kalimat di bawah untuk mencari maknanya:</div>", unsafe_allow_html=True)
input_text = st.text_input("", placeholder="Masukkan kata atau kalimat...")

# Logika untuk mencari definisi kata
if input_text:
    stemmed_word = stemmer.stem(input_text)
    
    # Menampilkan kata dasar yang diproses
    st.markdown(f"<div class='result-container' style='background-color: #E3F2FD; color: #0288D1;'>"
                f"Kata dasar yang diproses: <strong>{stemmed_word}</strong></div>",
                unsafe_allow_html=True)

    # Mencari definisi dalam dataset
    definition = get_kbbi_definition(stemmed_word, kbbi_data)
    
    # Menampilkan hasil definisi
    if definition != "Definisi tidak ditemukan dalam dataset.":
        st.markdown(f"<div class='result-container result-success'>"
                    f"Makna kata: <strong>{definition}</strong></div>",
                    unsafe_allow_html=True)
    else:
        st.markdown(f"<div class='result-container result-error'>"
                    f"{definition}</div>",
                    unsafe_allow_html=True)



